
#ifndef SEARCHRESULT_H
#define SEARCHRESULT_H

class searchResult {

public:

    QString searchName,
    name,
    file,
    size,
    seeders,
    leechers;

};

#endif
