
#ifndef TORRENTSEARCH_H
#define TORRENTSEARCH_H

class torrentSearch {

public:

    QString searchName,
    searchVersion,
    searchAuthor,
    searchHost,
    searchURL,
    torrentHost,
    torrentName,
    torrentFile,
    torrentSize,
    torrentSeeders,
    torrentLeechers;

};

#endif
