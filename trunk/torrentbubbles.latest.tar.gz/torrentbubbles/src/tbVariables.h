
#ifndef TBVARIABLES_H
#define TBVARIABLES_H

class tbVariables {

public:

    	QString author,
    	torrentProgram, 
	version;

};

#endif
